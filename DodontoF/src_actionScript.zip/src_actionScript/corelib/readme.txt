corelib ActionScript 3 Library
Release version .90

Project Homepage:
http://code.google.com/p/as3corelib/